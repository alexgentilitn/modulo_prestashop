<?php
/**
 * 2007-2025 PrestaShop.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License (AFL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://opensource.org/licenses/afl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future. If you wish to customize PrestaShop for your
 * needs please refer to http://www.prestashop.com for more information.
 *
 *  @author    PrestaShop SA <contact@prestashop.com>
 *  @copyright 2007-2025 PrestaShop SA
 *  @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 *  International Registered Trademark & Property of PrestaShop SA
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

include_once 'classes/tvcmsadvanceblock_status.class.php';
include_once 'classes/tvcmsadvanceblock_image_upload.class.php';
include_once _PS_MODULE_DIR_ . 'tvcmscustomsetting/classes/tvcmsresizemasterclass.php';

class TvcmsAdvanceBlock extends Module
{
    public function __construct()
    {
        $this->name = 'tvcmsadvanceblock';
        $this->tab = 'front_office_features';
        $this->version = '4.0.1';
        $this->author = 'ThemeVolty';
        $this->need_instance = 0;

        $this->bootstrap = true;
        parent::__construct();

        $this->displayName = $this->trans('ThemeVolty - Advance Block', [], 'Modules.Tvcmsadvanceblock.Admin');
        $this->description = $this->trans('Its Show Advance Block on Front Side', [], 'Modules.Tvcmsadvanceblock.Admin');

        $this->ps_versions_compliancy = ['min' => '1.7', 'max' => _PS_VERSION_];
        $this->module_key = '';

        $this->confirmUninstall = $this->trans('Warning: all the data saved in your database will be deleted. Are you sure you want uninstall this module?', [], 'Modules.Tvcmsadvanceblock.Admin');
    }

    public function isUsingNewTranslationSystem()
    {
        return true;
    }

    public function install()
    {
        $this->installTab();
        $this->createTable();

        return parent::install()
            && $this->registerHook('displayBackOfficeHeader')
            && $this->registerHook('displayHeader')
            && $this->registerHook('displayHome');
    }

    public function installTab()
    {
        $response = true;

        // First check for parent tab
        $parentTabID = Tab::getIdFromClassName('AdminThemeVolty');

        if ($parentTabID) {
            $parentTab = new Tab($parentTabID);
        } else {
            $parentTab = new Tab();
            $parentTab->active = 1;
            $parentTab->name = [];
            $parentTab->class_name = 'AdminThemeVolty';
            foreach (Language::getLanguages() as $lang) {
                $parentTab->name[$lang['id_lang']] = 'ThemeVolty Configure';
            }
            $parentTab->id_parent = 0;
            $parentTab->module = $this->name;
            $response &= $parentTab->add();
        }

        // Check for parent tab2
        $parentTab_2ID = Tab::getIdFromClassName('AdminThemeVoltyModules');
        if ($parentTab_2ID) {
            $parentTab_2 = new Tab($parentTab_2ID);
        } else {
            $parentTab_2 = new Tab();
            $parentTab_2->active = 1;
            $parentTab_2->name = [];
            $parentTab_2->class_name = 'AdminThemeVoltyModules';
            foreach (Language::getLanguages() as $lang) {
                $parentTab_2->name[$lang['id_lang']] = 'ThemeVolty Configure';
            }
            $parentTab_2->id_parent = $parentTab->id;
            $parentTab_2->module = $this->name;
            $response &= $parentTab_2->add();
        }
        // Created tab
        $tab = new Tab();
        $tab->active = 1;
        $tab->class_name = 'Admin' . $this->name;
        $tab->name = [];
        foreach (Language::getLanguages() as $lang) {
            $tab->name[$lang['id_lang']] = 'Advance Block';
        }
        $tab->id_parent = $parentTab_2->id;
        $tab->module = $this->name;
        $response &= $tab->add();

        return $response;
    }

    public function createDefaultData()
    {
        $this->reset();
        $num_of_data = 3;
        $this->createVariable();
        $this->createTable();
        $this->insertSmapleData($num_of_data);
    }

    public function createVariable()
    {
        $languages = Language::getLanguages();
        $result = [];
        foreach ($languages as $lang) {
            $result['TVCMSADVANCEBLOCK_TITLE'][$lang['id_lang']] = 'AUTOTRICS';
            $result['TVCMSADVANCEBLOCK_SUB_DESCRIPTION'][$lang['id_lang']] = 'WHY CHOOSE';
            $result['TVCMSADVANCEBLOCK_DESCRIPTION'][$lang['id_lang']] = 'Description';
            $result['TVCMSADVANCEBLOCK_IMG'][$lang['id_lang']] = 'demo_main_img.jpg';

            $result['TVCMSADVANCEBLOCK_MAIN_BLOCK_SUB_TITLE'][$lang['id_lang']] = 'FUTURE OF MAC';
            $result['TVCMSADVANCEBLOCK_MAIN_BLOCK_TITLE'][$lang['id_lang']] = 'Our Workshops & Classes Earthenre Beautiful';
            $result['TVCMSADVANCEBLOCK_MAIN_BLOCK_SUB_DESCRIPTION'][$lang['id_lang']] = 'Short Description';
            $result['TVCMSADVANCEBLOCK_MAIN_BLOCK_DESCRIPTION'][$lang['id_lang']] = 'Be yourself, follow your heart! In yogic sense, the phrase “be yourself follow heart” has a deeper meaning. It means aligning not only with the attb butes of your but also aligning with your true nature.';
            $result['TVCMSADVANCEBLOCK_MAIN_BLOCK_LINK'][$lang['id_lang']] = '#';
            $result['TVCMSADVANCEBLOCK_MAIN_BLOCK_BTN_CAPTION'][$lang['id_lang']] = 'READ MORE';
            $result['TVCMSADVANCEBLOCK_MAIN_BLOCK_IMG'][$lang['id_lang']] = 'demo_main_block_img.png';
            $result['TVCMSADVANCEBLOCK_MAIN_BLOCK_BACK_IMG'][$lang['id_lang']] = 'demo_main_block_back_img.jpg';

            // Image Resize
            // $path = dirname(__FILE__).'/views/img/';
            // $ImageName =  'demo_main_block_img.png';
            // if (file_exists($path.$ImageName)) {
            //     $MediumImgPath = $path.'medium/';
            //     if (!is_dir($MediumImgPath)) {
            //         mkdir($MediumImgPath);
            //     }
            //     $resizeObj = new TvcmsResizeMasterClass($path.$ImageName);
            //     $resizeObj->resizeImage(770, 770, 4);
            //     $resizeObj->saveImage($MediumImgPath.$ImageName);
            //     $SmallImgPath = $path.'small/';
            //     if (!is_dir($SmallImgPath)) {
            //         mkdir($SmallImgPath);
            //     }
            //     $resizeObj = new TvcmsResizeMasterClass($path.$ImageName);
            //     $resizeObj->resizeImage(500, 500, 4);
            //     $resizeObj->saveImage($SmallImgPath.$ImageName);
            // }
            // Image Resize

            // Image Resize
            // $path = dirname(__FILE__).'/views/img/';
            // $ImageName =  'demo_main_block_back_img.jpg';
            // if (file_exists($path.$ImageName)) {
            //     $MediumImgPath = $path.'medium/';
            //     if (!is_dir($MediumImgPath)) {
            //         mkdir($MediumImgPath);
            //     }
            //     $resizeObj = new TvcmsResizeMasterClass($path.$ImageName);
            //     $resizeObj->resizeImage(770, 770, 4);
            //     $resizeObj->saveImage($MediumImgPath.$ImageName);
            //     $SmallImgPath = $path.'small/';
            //     if (!is_dir($SmallImgPath)) {
            //         mkdir($SmallImgPath);
            //     }
            //     $resizeObj = new TvcmsResizeMasterClass($path.$ImageName);
            //     $resizeObj->resizeImage(500, 500, 4);
            //     $resizeObj->saveImage($SmallImgPath.$ImageName);
            // }
            // Image Resize

            $result['TVCMSADVANCEBLOCK_MAIN_BLOCK_TIMER_TITLE'][$lang['id_lang']] = 'OFFER ENDS IN';
            $result['TVCMSADVANCEBLOCK_MAIN_BLOCK_TIMER_END_DATE'][$lang['id_lang']] = date('Y-m-d', strtotime(date('Y-m-d') . ' + 1 day'));
        }

        Configuration::updateValue('TVCMSADVANCEBLOCK_TITLE', $result['TVCMSADVANCEBLOCK_TITLE']);
        Configuration::updateValue('TVCMSADVANCEBLOCK_SUB_DESCRIPTION', $result['TVCMSADVANCEBLOCK_SUB_DESCRIPTION']);
        Configuration::updateValue('TVCMSADVANCEBLOCK_DESCRIPTION', $result['TVCMSADVANCEBLOCK_DESCRIPTION']);
        Configuration::updateValue('TVCMSADVANCEBLOCK_IMG', $result['TVCMSADVANCEBLOCK_IMG']);

        $tmp = $result['TVCMSADVANCEBLOCK_MAIN_BLOCK_SUB_TITLE'];
        Configuration::updateValue('TVCMSADVANCEBLOCK_MAIN_BLOCK_SUB_TITLE', $tmp);
        $tmp = $result['TVCMSADVANCEBLOCK_MAIN_BLOCK_TITLE'];
        Configuration::updateValue('TVCMSADVANCEBLOCK_MAIN_BLOCK_TITLE', $tmp);
        $tmp = $result['TVCMSADVANCEBLOCK_MAIN_BLOCK_SUB_DESCRIPTION'];
        Configuration::updateValue('TVCMSADVANCEBLOCK_MAIN_BLOCK_SUB_DESCRIPTION', $tmp);
        $tmp = $result['TVCMSADVANCEBLOCK_MAIN_BLOCK_DESCRIPTION'];
        Configuration::updateValue('TVCMSADVANCEBLOCK_MAIN_BLOCK_DESCRIPTION', $tmp);
        $tmp = $result['TVCMSADVANCEBLOCK_MAIN_BLOCK_LINK'];
        Configuration::updateValue('TVCMSADVANCEBLOCK_MAIN_BLOCK_LINK', $tmp);
        $tmp = $result['TVCMSADVANCEBLOCK_MAIN_BLOCK_BTN_CAPTION'];
        Configuration::updateValue('TVCMSADVANCEBLOCK_MAIN_BLOCK_BTN_CAPTION', $tmp);
        Configuration::updateValue('TVCMSADVANCEBLOCK_MAIN_BLOCK_IMG', $result['TVCMSADVANCEBLOCK_MAIN_BLOCK_IMG']);
        Configuration::updateValue('TVCMSADVANCEBLOCK_MAIN_BLOCK_BACK_IMG', $result['TVCMSADVANCEBLOCK_MAIN_BLOCK_BACK_IMG']);

        $tmp = $result['TVCMSADVANCEBLOCK_MAIN_BLOCK_TIMER_TITLE'];
        Configuration::updateValue('TVCMSADVANCEBLOCK_MAIN_BLOCK_TIMER_TITLE', $tmp);

        $tmp = date('Y-m-d', strtotime(date('Y-m-d') . ' + 2 days'));
        Configuration::updateValue('TVCMSADVANCEBLOCK_MAIN_BLOCK_TIMER_END_DATE', $tmp, true);
    }

    public function createTable()
    {
        $create_table = [];
        $create_table[] = 'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'tvcmsadvanceblock` (
                        `id_tvcmsadvanceblock` int(11) AUTO_INCREMENT PRIMARY KEY,
                        `position` int(11),
                        `image` VARCHAR(100),
                        `link` VARCHAR(255),
                        `status` varchar(3)
                    ) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8;';

        $create_table[] = 'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'tvcmsadvanceblock_lang` (
                        `id_tvcmsadvanceblock_lang` INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
                        `id_tvcmsadvanceblock` INT NOT NULL,
                        `id_lang` INT NOT NULL,
                        `title` VARCHAR(255),
                        `short_description` TEXT,
                        `description` TEXT
                    ) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8;';

        foreach ($create_table as $table) {
            Db::getInstance()->execute($table);
        }
    }

    public function insertSmapleData($num_of_data)
    {
        $demo_data = [];
        $languages = Language::getLanguages();

        for ($i = 1; $i <= $num_of_data; ++$i) {
            $demo_data[] = 'INSERT INTO 
                            `' . _DB_PREFIX_ . 'tvcmsadvanceblock`
                        SET 
                            `id_tvcmsadvanceblock` = ' . $i . ',
                            `position` = ' . $i . ',
                            `image` = \'demo_img_' . $i . '.png\',
                            `link` = \'#\',
                            `status` = \'1\';';
            foreach ($languages as $lang) {
                if (1 == $i) {
                    $title = 'Car Parts Shop';
                    $short_desc = 'Expert Engineering is focused on delivering quality products at a time and provide the best solution.';
                    $desc = 'Expert Engineering is focused on delivering quality products at a time and provide the best solution.';
                } elseif (2 == $i) {
                    $title = 'Provide Quality Service';
                    $short_desc = 'Water Twice a Week ';
                    $desc = 'Water Twice a Week ';
                } elseif (3 == $i) {
                    $title = 'Where To Grow';
                    $short_desc = 'Service quality generally refers to a customers comparison of service expectations as it relates to a companys performance.';
                    $desc = 'Service quality generally refers to a customers comparison of service expectations as it relates to a companys performance.';
                } elseif (4 == $i) {
                    $title = 'We Gave 100% satisfaction';
                    $short_desc = 'Customer satisfaction indicates the fulfillment that customers derive from doing business';
                    $desc = 'Customer satisfaction indicates the fulfillment that customers derive from doing business';
                } elseif (5 == $i) {
                    $title = 'Special Feature';
                    $short_desc = 'Air Purifying';
                    $desc = 'Air Purifying';
                } else {
                    $title = 'This is a very unfriendly wine. It hits your mouth and then turns it inside out. It usually means the wine has very high acidity and very little fruit flavors. An austere wine is not fruit-forward nor opulent.' . $i;
                    $short_desc = 'This is a very unfriendly wine. It hits your mouth and then turns it inside out. It usually means the wine has very high acidity and very little fruit flavors. An austere wine is not fruit-forward nor opulent.' . $i;
                    $desc = 'This is a very unfriendly wine. It hits your mouth and then turns it inside out. It usually means the wine has very high acidity and very little fruit flavors. An austere wine is not fruit-forward nor opulent.' . $i;
                }
                $demo_data[] = 'INSERT INTO
                                `' . _DB_PREFIX_ . 'tvcmsadvanceblock_lang`
                            SET
                                `id_tvcmsadvanceblock_lang` = NULL,
                                `id_tvcmsadvanceblock` = ' . $i . ',
                                `id_lang` = ' . (int) $lang['id_lang'] . ',
                                `title` = \'' . pSQL($title) . '\',
                                `short_description` = \'' . pSQL($short_desc) . '\',
                                `description` = \'' . pSQL($desc) . '\';';
            }
        }
        foreach ($demo_data as $data) {
            Db::getInstance()->execute($data);
        }
    }

    public function maxId()
    {
        $select_data = 'SELECT MAX(id_tvcmsadvanceblock) as max_id FROM `' . _DB_PREFIX_ . 'tvcmsadvanceblock`';
        $ans = Db::getInstance()->executeS($select_data);

        return $ans[0]['max_id'];
    }

    public function selectAllLangIdById($id_tvcmsadvanceblock)
    {
        $select_data = 'SELECT 
                            id_lang 
                        FROM 
                            `' . _DB_PREFIX_ . 'tvcmsadvanceblock_lang` 
                        WHERE 
                            id_tvcmsadvanceblock = ' . (int) $id_tvcmsadvanceblock;
        $ans = Db::getInstance()->executeS($select_data);
        $return = [];
        foreach ($ans as $a) {
            $return[] = $a['id_lang'];
        }

        return $return;
    }

    public function insertData($data)
    {
        $result = [];
        $insert_data = [];
        if ($data['id']) {
            $id = $data['id'];
            $insert_data[] = 'UPDATE 
                                `' . _DB_PREFIX_ . 'tvcmsadvanceblock` 
                            SET
                                `image` = \'' . pSQL($data['image']) . '\',
                                `link` = \'' . pSQL($data['link']) . '\',
                                `status` = ' . (int) $data['status'] . '
                            WHERE
                                `id_tvcmsadvanceblock` = ' . (int) $id . ';';
            $result = $this->selectAllLangIdById($id);

            $languages = Language::getLanguages();
            $i = 0;
            foreach ($languages as $lang) {
                if (in_array($lang['id_lang'], $result)) {
                    $insert_data[] = 'UPDATE
                                        `' . _DB_PREFIX_ . 'tvcmsadvanceblock_lang`
                                    SET
                                        `title` = \'' . pSQL($data['lang_info'][$i]['title']) . '\',
                                        `short_description` = \'' . pSQL($data['lang_info'][$i]['short_description']) . '\',
                                        `description` = \'' . pSQL($data['lang_info'][$i]['description']) . '\'
                                    WHERE
                                            `id_tvcmsadvanceblock` = ' . (int) $id . '
                                        AND
                                            `id_lang` = ' . (int) $lang['id_lang'] . ';';
                } else {
                    $insert_data[] = 'INSERT INTO
                                        `' . _DB_PREFIX_ . 'tvcmsadvanceblock_lang`
                                    SET
                                        `id_tvcmsadvanceblock_lang` = NULL,
                                        `id_tvcmsadvanceblock` = ' . (int) $id . ',
                                        `id_lang` = ' . (int) $lang['id_lang'] . ',
                                        `title` = \'' . pSQL($data['lang_info'][$i]['title']) . '\',
                                        `short_description` = \'' . pSQL($data['lang_info'][$i]['short_description']) . '\',
                                        `description` = \'' . pSQL($data['lang_info'][$i]['description']) . '\';';
                }
                ++$i;
            }
        } else {
            $max_id = $this->maxId();
            $new_id = $max_id + 1;
            $insert_data = [];

            $insert_data[] = 'INSERT INTO 
                                `' . _DB_PREFIX_ . 'tvcmsadvanceblock` 
                            SET
                                `id_tvcmsadvanceblock` = ' . (int) $new_id . ',
                                `position` = ' . (int) $new_id . ',
                                `image` = \'' . pSQL($data['image']) . '\',
                                `link` = \'' . pSQL($data['link']) . '\',
                                `status` = ' . (int) $data['status'] . ';';

            foreach ($data['lang_info'] as $lang) {
                $insert_data[] = 'INSERT INTO
                                    `' . _DB_PREFIX_ . 'tvcmsadvanceblock_lang`
                                SET
                                    `id_tvcmsadvanceblock_lang` = NULL,
                                    `id_tvcmsadvanceblock` = ' . (int) $new_id . ',
                                    `id_lang` = ' . (int) $lang['id_lang'] . ',
                                    `title` = \'' . pSQL($lang['title']) . '\',
                                    `short_description` = \'' . pSQL($lang['short_description']) . '\',
                                    `description` = \'' . pSQL($lang['description']) . '\';';
            }
        }
        // echo "<pre>";
        // print_r($insert_data);

        // exit;
        foreach ($insert_data as $data) {
            Db::getInstance()->execute($data);
        }
    }

    public function showAdminData()
    {
        $result = [];
        $return_data = [];
        $default_lang_id = $this->context->language->id;

        $select_data = 'SELECT * FROM `' . _DB_PREFIX_ . 'tvcmsadvanceblock` ORDER BY `position`';
        $result['tvcmsadvanceblock'] = Db::getInstance()->executeS($select_data);

        $select_data = 'SELECT * FROM `' . _DB_PREFIX_ . 'tvcmsadvanceblock_lang`';
        $result['tvcmsadvanceblock_lang'] = Db::getInstance()->executeS($select_data);

        foreach ($result['tvcmsadvanceblock'] as $key => $data) {
            $return_data[$key]['id'] = $data['id_tvcmsadvanceblock'];
            $id = $data['id_tvcmsadvanceblock'];

            foreach ($result['tvcmsadvanceblock_lang'] as $lang) {
                if ($default_lang_id == $lang['id_lang'] && $id == $lang['id_tvcmsadvanceblock']) {
                    // $lang_id = $lang['id_lang'];
                    $return_data[$key]['id_lang'] = $lang['id_lang'];
                    $return_data[$key]['title'] = $lang['title'];
                    $return_data[$key]['short_description'] = $lang['short_description'];
                    $return_data[$key]['description'] = $lang['description'];
                }
            }

            $return_data[$key]['image'] = $data['image'];
            $return_data[$key]['link'] = $data['link'];
            $return_data[$key]['status'] = $data['status'];
        }

        return $return_data;
    }

    public function showData($id = null)
    {
        $select_data = [];
        $result = [];
        $return_data = [];

        $select_data = '';
        $select_data .= 'SELECT * FROM `' . _DB_PREFIX_ . 'tvcmsadvanceblock` ';

        if (!empty($id)) {
            $select_data .= 'WHERE id_tvcmsadvanceblock = ' . (int) $id;
        } else {
            $select_data .= 'ORDER BY `position`';
        }

        $result['tvcmsadvanceblock'] = Db::getInstance()->executeS($select_data);

        $select_data = '';
        $select_data .= 'SELECT * FROM `' . _DB_PREFIX_ . 'tvcmsadvanceblock_lang`';
        if (!empty($id)) {
            $select_data .= 'WHERE id_tvcmsadvanceblock = ' . (int) $id;
        }
        $result['tvcmsadvanceblock_lang'] = Db::getInstance()->executeS($select_data);

        foreach ($result['tvcmsadvanceblock'] as $key => $data) {
            $return_data[$key]['id'] = $data['id_tvcmsadvanceblock'];
            $id = $data['id_tvcmsadvanceblock'];
            foreach ($result['tvcmsadvanceblock_lang'] as $lang) {
                if ($id == $lang['id_tvcmsadvanceblock']) {
                    $lang_id = $lang['id_lang'];
                    $return_data[$key]['lang_info'][$lang_id]['id_lang'] = $lang['id_lang'];
                    $return_data[$key]['lang_info'][$lang_id]['title'] = $lang['title'];
                    $return_data[$key]['lang_info'][$lang_id]['short_description'] = $lang['short_description'];
                    $return_data[$key]['lang_info'][$lang_id]['description'] = $lang['description'];
                }
            }
            $return_data[$key]['image'] = $data['image'];
            $return_data[$key]['link'] = $data['link'];
            $return_data[$key]['status'] = $data['status'];
        }

        return $return_data;
    }

    public function uninstall()
    {
        $this->uninstallTab();
        $this->deleteVariable();
        $this->deleteTable();

        return parent::uninstall();
    }

    public function deleteVariable()
    {
        Configuration::deleteByName('TVCMSADVANCEBLOCK_TITLE');
        Configuration::deleteByName('TVCMSADVANCEBLOCK_SUB_DESCRIPTION');
        Configuration::deleteByName('TVCMSADVANCEBLOCK_DESCRIPTION');
        Configuration::deleteByName('TVCMSADVANCEBLOCK_IMG');

        Configuration::deleteByName('TVCMSADVANCEBLOCK_MAIN_BLOCK_SUB_TITLE');
        Configuration::deleteByName('TVCMSADVANCEBLOCK_MAIN_BLOCK_TITLE');
        Configuration::deleteByName('TVCMSADVANCEBLOCK_MAIN_BLOCK_SUB_DESCRIPTION');
        Configuration::deleteByName('TVCMSADVANCEBLOCK_MAIN_BLOCK_DESCRIPTION');
        Configuration::deleteByName('TVCMSADVANCEBLOCK_MAIN_BLOCK_LINK');
        Configuration::deleteByName('TVCMSADVANCEBLOCK_MAIN_BLOCK_BTN_CAPTION');
        Configuration::deleteByName('TVCMSADVANCEBLOCK_MAIN_BLOCK_IMG');
        Configuration::deleteByName('TVCMSADVANCEBLOCK_MAIN_BLOCK_BACK_IMG');

        Configuration::deleteByName('TVCMSADVANCEBLOCK_MAIN_BLOCK_TIMER_TITLE');
        Configuration::deleteByName('TVCMSADVANCEBLOCK_MAIN_BLOCK_TIMER_END_DATE');
    }

    public function deleteRecord($id)
    {
        $this->removeImage($id);

        $delete_data = [];
        $delete_data[] = 'DELETE FROM `' . _DB_PREFIX_ . 'tvcmsadvanceblock` WHERE id_tvcmsadvanceblock = ' . (int) $id;
        $delete_data[] = 'DELETE FROM `' . _DB_PREFIX_ . 'tvcmsadvanceblock_lang` WHERE id_tvcmsadvanceblock = ' . (int) $id;

        foreach ($delete_data as $data) {
            Db::getInstance()->execute($data);
        }
    }

    public function removeImage($id)
    {
        $remove_images = [];
        $result = $this->showData($id);

        $remove_images[] = $result[0]['image'];

        foreach ($remove_images as $image) {
            // Match Pattern Which image you Don't want to delete.
            $res = preg_match('/^demo_main_img.*$/', $image);
            $res2 = preg_match('/^demo_img_.*$/', $image);

            if (file_exists(dirname(__FILE__) . './views/img/' . $image)
                && '1' != $res
                && '1' != $res2) {
                unlink(dirname(__FILE__) . './views/img/' . $image);
            }
        }
    }

    public function deleteTable()
    {
        $delete_table = [];
        $delete_table[] = 'DROP TABLE IF EXISTS `' . _DB_PREFIX_ . 'tvcmsadvanceblock`';
        $delete_table[] = 'DROP TABLE IF EXISTS `' . _DB_PREFIX_ . 'tvcmsadvanceblock_lang`';

        foreach ($delete_table as $table) {
            Db::getInstance()->execute($table);
        }
    }

    public function uninstallTab()
    {
        $id_tab = Tab::getIdFromClassName('Admin' . $this->name);
        $tab = new Tab($id_tab);
        $tab->delete();

        return true;
    }

    public function getContent()
    {
        $useSSL = (isset($this->ssl) && $this->ssl && Configuration::get('PS_SSL_ENABLED')) || Tools::usingSecureMode() ? true : false;
        $protocol_content = $useSSL ? 'https://' : 'http://';
        $baseDir = $protocol_content . Tools::getHttpHost() . __PS_BASE_URI__;
        $link = PS_ADMIN_DIR;
        if (Tools::substr(strrchr($link, '/'), 1)) {
            $admin_folder = Tools::substr(strrchr($link, '/'), 1);
        } else {
            $admin_folder = Tools::substr(strrchr($link, "\'"), 1);
        }
        $static_token = Tools::getAdminToken('AdminModules' . (int) Tab::getIdFromClassName('AdminModules') . (int) $this->context->employee->id);
        $url_slidersampleupgrade = $baseDir . $admin_folder . '/index.php?controller=AdminModules&configure=' . $this->name . '&tab_module=front_office_features&module_name=' . $this->name . '&token=' . $static_token;
        $this->context->smarty->assign('tvurlupgrade', $url_slidersampleupgrade);

        if (Tools::isSubmit('submitTvcmsSampleinstall')) {
            $this->createDefaultData();
        }

        $message = $this->postProcess();
        $output = $message
                . $this->renderForm()
                . $this->showAdminResult();

        return $output;
    }

    public function reset()
    {
        $trn_tbl = [];
        $trn_tbl[] = 'TRUNCATE `' . _DB_PREFIX_ . 'tvcmsadvanceblock`';
        $trn_tbl[] = 'TRUNCATE `' . _DB_PREFIX_ . 'tvcmsadvanceblock_lang`';
        foreach ($trn_tbl as $table) {
            Db::getInstance()->execute($table);
        }
    }

    public function postProcess()
    {
        $message = '';
        $result = [];

        $no_image_selected = false;
        if (Tools::getValue('action')) {
            if ('remove' == Tools::getValue('action')) {
                $id = Tools::getValue('id');
                $this->deleteRecord($id);
                $message .= $this->displayConfirmation($this->trans('Record is Deleted.', [], 'Modules.Tvcmsadvanceblock.Admin'));
            }
        }

        if (Tools::isSubmit('submitvcmsAdvanceBlockForm')) {
            $old_file = '';
            $result['id'] = '';
            if (Tools::getValue('id')) {
                $result['id'] = Tools::getValue('id');
                $id = $result['id'];
                $res = $this->showData($id);
                $old_file = $res[0]['image'];
            }

            $tvcms_obj = new TvcmsAdvanceBlockStatus();
            $show_fields = $tvcms_obj->fieldStatusInformation();
            if ($show_fields['image']) {
                if (!empty($_FILES['image']['name'])) {
                    $new_file = $_FILES['image'];
                    $obj_image = new TvcmsAdvanceBlockImageUpload();
                    $ans = $obj_image->imageUploading($new_file, $old_file);

                    if ($ans['success']) {
                        $result['image'] = $ans['name'];
                    } else {
                        $message .= $ans['error'];
                        $result['image'] = $old_file;
                        if (!Tools::getValue('id')) {
                            $no_image_selected = true;
                        }
                    }
                } else {
                    $result['image'] = $old_file;
                    if (!Tools::getValue('id')) {
                        $message .= $this->displayError($this->trans('Please Select Image.', [], 'Modules.Tvcmsadvanceblock.Admin'));
                        $no_image_selected = true;
                    }
                }
            }
            if (!$no_image_selected) {
                $result['link'] = Tools::getValue('link');
                $result['status'] = Tools::getValue('status');

                $languages = Language::getLanguages();
                $i = 0;
                foreach ($languages as $lang) {
                    $result['lang_info'][$i]['id_lang'] = $lang['id_lang'];
                    $tmp = Tools::getValue('title_' . $lang['id_lang']);
                    $result['lang_info'][$i]['title'] = addslashes($tmp);
                    $tmp = Tools::getValue('short_description_' . $lang['id_lang']);
                    $result['lang_info'][$i]['short_description'] = addslashes($tmp);
                    $tmp = Tools::getValue('description_' . $lang['id_lang']);
                    $result['lang_info'][$i]['description'] = addslashes($tmp);
                    ++$i;
                }
                $this->insertData($result);
                if (Tools::getValue('id')) {
                    $message .= $this->displayConfirmation($this->trans('Record is Updated.', [], 'Modules.Tvcmsadvanceblock.Admin'));
                } else {
                    $message .= $this->displayConfirmation($this->trans('Record is Inserted.', [], 'Modules.Tvcmsadvanceblock.Admin'));
                }
            }
        }

        if (Tools::isSubmit('submitvcmsAdvanceBlockMainTitleForm')) {
            $languages = Language::getLanguages();
            $obj_image = new TvcmsAdvanceBlockImageUpload();
            foreach ($languages as $lang) {
                if (!empty($_FILES['TVCMSADVANCEBLOCK_IMG_' . $lang['id_lang']]['name'])) {
                    $old_file = Configuration::get('TVCMSADVANCEBLOCK_IMG', $lang['id_lang']);
                    $new_file = $_FILES['TVCMSADVANCEBLOCK_IMG_' . $lang['id_lang']];
                    $ans = $obj_image->imageUploading($new_file, $old_file);
                    if ($ans['success']) {
                        $result['TVCMSADVANCEBLOCK_IMG'][$lang['id_lang']] = $ans['name'];
                    } else {
                        $message .= $ans['error'];
                        $result['TVCMSADVANCEBLOCK_IMG'][$lang['id_lang']] = $old_file;
                    }
                } else {
                    $old_file = Configuration::get('TVCMSADVANCEBLOCK_IMG', $lang['id_lang']);
                    $result['TVCMSADVANCEBLOCK_IMG'][$lang['id_lang']] = $old_file;
                }

                $tmp = Tools::getValue('TVCMSADVANCEBLOCK_TITLE_' . $lang['id_lang']);
                $result['TVCMSADVANCEBLOCK_TITLE'][$lang['id_lang']] = $tmp;

                $tmp = Tools::getValue('TVCMSADVANCEBLOCK_SUB_DESCRIPTION_' . $lang['id_lang']);
                $result['TVCMSADVANCEBLOCK_SUB_DESCRIPTION'][$lang['id_lang']] = $tmp;

                $tmp = Tools::getValue('TVCMSADVANCEBLOCK_DESCRIPTION_' . $lang['id_lang']);
                $result['TVCMSADVANCEBLOCK_DESCRIPTION'][$lang['id_lang']] = $tmp;
            }
            Configuration::updateValue('TVCMSADVANCEBLOCK_IMG', $result['TVCMSADVANCEBLOCK_IMG']);
            Configuration::updateValue('TVCMSADVANCEBLOCK_TITLE', $result['TVCMSADVANCEBLOCK_TITLE']);
            $tmp = $result['TVCMSADVANCEBLOCK_SUB_DESCRIPTION'];
            Configuration::updateValue('TVCMSADVANCEBLOCK_SUB_DESCRIPTION', $tmp);

            $tmp = $result['TVCMSADVANCEBLOCK_DESCRIPTION'];
            Configuration::updateValue('TVCMSADVANCEBLOCK_DESCRIPTION', $tmp);
            $message .= $this->displayConfirmation($this->trans('Main Title is Updated.', [], 'Modules.Tvcmsadvanceblock.Admin'));
        }

        if (Tools::isSubmit('submitvcmsAdvanceBlockMainBlockForm')) {
            $languages = Language::getLanguages();
            $obj_image = new TvcmsAdvanceBlockImageUpload();

            foreach ($languages as $lang) {
                if (!empty($_FILES['TVCMSADVANCEBLOCK_MAIN_BLOCK_IMG_' . $lang['id_lang']]['name'])) {
                    $old_file = Configuration::get('TVCMSADVANCEBLOCK_MAIN_BLOCK_IMG', $lang['id_lang']);
                    $old_file_main = Configuration::get('TVCMSADVANCEBLOCK_MAIN_BLOCK_IMG', $lang['id_lang']);
                    $new_file = $_FILES['TVCMSADVANCEBLOCK_MAIN_BLOCK_IMG_' . $lang['id_lang']];
                    $ans = $obj_image->imageUploading($new_file, $old_file);
                    if ($ans['success']) {
                        $result['TVCMSADVANCEBLOCK_MAIN_BLOCK_IMG'][$lang['id_lang']] = $ans['name'];
                    } else {
                        $message .= $ans['error'];
                        $result['TVCMSADVANCEBLOCK_MAIN_BLOCK_IMG'][$lang['id_lang']] = $old_file;
                    }
                } else {
                    $old_file = Configuration::get('TVCMSADVANCEBLOCK_MAIN_BLOCK_IMG', $lang['id_lang']);
                    $result['TVCMSADVANCEBLOCK_MAIN_BLOCK_IMG'][$lang['id_lang']] = $old_file;
                }

                // Remove tv resize images
                // $tvpath = dirname(__FILE__).'/views/img/';
                // $MediumImgPath = $tvpath.'medium/'.$old_file_main;
                // if (file_exists($MediumImgPath)) {
                //     @unlink($MediumImgPath);
                // }
                // $SmallImgPath = $tvpath.'small/'.$old_file_main;
                // if (file_exists($SmallImgPath)) {
                //     @unlink($SmallImgPath);
                // }
                // Remove tv resize images

                // Image Resize
                // $path = dirname(__FILE__).'/views/img/';
                // $ImageName = $result['TVCMSADVANCEBLOCK_MAIN_BLOCK_IMG'][$lang['id_lang']];
                // if (file_exists($path.$ImageName)) {
                //     $MediumImgPath = $path.'medium/';
                //     if (!is_dir($MediumImgPath)) {
                //         mkdir($MediumImgPath);
                //     }
                //     $resizeObj = new TvcmsResizeMasterClass($path.$ImageName);
                //     $resizeObj->resizeImage(770, 770, 4);
                //     $resizeObj->saveImage($MediumImgPath.$ImageName);

                //     $SmallImgPath = $path.'small/';
                //     if (!is_dir($SmallImgPath)) {
                //         mkdir($SmallImgPath);
                //     }
                //     $resizeObj = new TvcmsResizeMasterClass($path.$ImageName);
                //     $resizeObj->resizeImage(500, 500, 4);
                //     $resizeObj->saveImage($SmallImgPath.$ImageName);
                // }

                // Remove tv resize images

                if (!empty($_FILES['TVCMSADVANCEBLOCK_MAIN_BLOCK_BACK_IMG_' . $lang['id_lang']]['name'])) {
                    $old_file = Configuration::get('TVCMSADVANCEBLOCK_MAIN_BLOCK_BACK_IMG', $lang['id_lang']);
                    $old_file_back = Configuration::get('TVCMSADVANCEBLOCK_MAIN_BLOCK_BACK_IMG', $lang['id_lang']);
                    $new_file = $_FILES['TVCMSADVANCEBLOCK_MAIN_BLOCK_BACK_IMG_' . $lang['id_lang']];
                    $ans = $obj_image->imageUploading($new_file, $old_file);
                    if ($ans['success']) {
                        $result['TVCMSADVANCEBLOCK_MAIN_BLOCK_BACK_IMG'][$lang['id_lang']] = $ans['name'];
                    } else {
                        $message .= $ans['error'];
                        $result['TVCMSADVANCEBLOCK_MAIN_BLOCK_BACK_IMG'][$lang['id_lang']] = $old_file;
                    }
                } else {
                    $old_file = Configuration::get('TVCMSADVANCEBLOCK_MAIN_BLOCK_BACK_IMG', $lang['id_lang']);
                    $result['TVCMSADVANCEBLOCK_MAIN_BLOCK_BACK_IMG'][$lang['id_lang']] = $old_file;
                }

                // Remove tv resize images
                // $tvpath = dirname(__FILE__).'/views/img/';
                // $MediumImgPath = $tvpath.'medium/'.$old_file_back;
                // if (file_exists($MediumImgPath)) {
                //     @unlink($MediumImgPath);
                // }
                // $SmallImgPath = $tvpath.'small/'.$old_file_back;
                // if (file_exists($SmallImgPath)) {
                //     @unlink($SmallImgPath);
                // }
                // Remove tv resize images

                // Image Resize
                // $path = dirname(__FILE__).'/views/img/';
                // $ImageName = $result['TVCMSADVANCEBLOCK_MAIN_BLOCK_BACK_IMG'][$lang['id_lang']];
                // if (file_exists($path.$ImageName)) {
                //     $MediumImgPath = $path.'medium/';
                //     if (!is_dir($MediumImgPath)) {
                //         mkdir($MediumImgPath);
                //     }

                //     $resizeObj = new TvcmsResizeMasterClass($path.$ImageName);
                //     $resizeObj->resizeImage(770, 770, 4);
                //     $resizeObj->saveImage($MediumImgPath.$ImageName);

                //     $SmallImgPath = $path.'small/';
                //     if (!is_dir($SmallImgPath)) {
                //         mkdir($SmallImgPath);
                //     }

                //     $resizeObj = new TvcmsResizeMasterClass($path.$ImageName);
                //     $resizeObj->resizeImage(500, 500, 4);
                //     $resizeObj->saveImage($SmallImgPath.$ImageName);
                // }

                // Remove tv resize images

                $tmp = Tools::getValue('TVCMSADVANCEBLOCK_MAIN_BLOCK_SUB_TITLE_' . $lang['id_lang']);
                $result['TVCMSADVANCEBLOCK_MAIN_BLOCK_SUB_TITLE'][$lang['id_lang']] = $tmp;

                $tmp = Tools::getValue('TVCMSADVANCEBLOCK_MAIN_BLOCK_TITLE_' . $lang['id_lang']);
                $result['TVCMSADVANCEBLOCK_MAIN_BLOCK_TITLE'][$lang['id_lang']] = $tmp;

                $tmp = Tools::getValue('TVCMSADVANCEBLOCK_MAIN_BLOCK_SUB_DESCRIPTION_' . $lang['id_lang']);
                $result['TVCMSADVANCEBLOCK_MAIN_BLOCK_SUB_DESCRIPTION'][$lang['id_lang']] = $tmp;

                $tmp = Tools::getValue('TVCMSADVANCEBLOCK_MAIN_BLOCK_DESCRIPTION_' . $lang['id_lang']);
                $result['TVCMSADVANCEBLOCK_MAIN_BLOCK_DESCRIPTION'][$lang['id_lang']] = $tmp;

                $tmp = Tools::getValue('TVCMSADVANCEBLOCK_MAIN_BLOCK_BTN_CAPTION_' . $lang['id_lang']);
                $result['TVCMSADVANCEBLOCK_MAIN_BLOCK_BTN_CAPTION'][$lang['id_lang']] = $tmp;

                $tmp = Tools::getValue('TVCMSADVANCEBLOCK_MAIN_BLOCK_LINK_' . $lang['id_lang']);
                $result['TVCMSADVANCEBLOCK_MAIN_BLOCK_LINK'][$lang['id_lang']] = $tmp;

                $tmp = Tools::getValue('TVCMSADVANCEBLOCK_MAIN_BLOCK_TIMER_TITLE_' . $lang['id_lang']);
                $result['TVCMSADVANCEBLOCK_MAIN_BLOCK_TIMER_TITLE'][$lang['id_lang']] = $tmp;

                // $tmp = Tools::getValue('TVCMSADVANCEBLOCK_MAIN_BLOCK_TIMER_END_DATE_' . $lang['id_lang']);
                // $result['TVCMSADVANCEBLOCK_MAIN_BLOCK_TIMER_END_DATE'][$lang['id_lang']] = $tmp;
            }

            $tmp = $result['TVCMSADVANCEBLOCK_MAIN_BLOCK_IMG'];
            Configuration::updateValue('TVCMSADVANCEBLOCK_MAIN_BLOCK_IMG', $tmp);
            $tmp = $result['TVCMSADVANCEBLOCK_MAIN_BLOCK_BACK_IMG'];
            Configuration::updateValue('TVCMSADVANCEBLOCK_MAIN_BLOCK_BACK_IMG', $tmp);
            $tmp = $result['TVCMSADVANCEBLOCK_MAIN_BLOCK_SUB_TITLE'];
            Configuration::updateValue('TVCMSADVANCEBLOCK_MAIN_BLOCK_SUB_TITLE', $tmp);
            $tmp = $result['TVCMSADVANCEBLOCK_MAIN_BLOCK_TITLE'];
            Configuration::updateValue('TVCMSADVANCEBLOCK_MAIN_BLOCK_TITLE', $tmp);
            $tmp = $result['TVCMSADVANCEBLOCK_MAIN_BLOCK_SUB_DESCRIPTION'];
            Configuration::updateValue('TVCMSADVANCEBLOCK_MAIN_BLOCK_SUB_DESCRIPTION', $tmp);
            $tmp = $result['TVCMSADVANCEBLOCK_MAIN_BLOCK_DESCRIPTION'];
            Configuration::updateValue('TVCMSADVANCEBLOCK_MAIN_BLOCK_DESCRIPTION', $tmp);
            $tmp = $result['TVCMSADVANCEBLOCK_MAIN_BLOCK_BTN_CAPTION'];
            Configuration::updateValue('TVCMSADVANCEBLOCK_MAIN_BLOCK_BTN_CAPTION', $tmp);
            $tmp = $result['TVCMSADVANCEBLOCK_MAIN_BLOCK_LINK'];
            Configuration::updateValue('TVCMSADVANCEBLOCK_MAIN_BLOCK_LINK', $tmp);

            $tmp = $result['TVCMSADVANCEBLOCK_MAIN_BLOCK_TIMER_TITLE'];
            Configuration::updateValue('TVCMSADVANCEBLOCK_MAIN_BLOCK_TIMER_TITLE', $tmp);

            $tmp = Tools::getValue('TVCMSADVANCEBLOCK_MAIN_BLOCK_TIMER_END_DATE');
            Configuration::updateValue('TVCMSADVANCEBLOCK_MAIN_BLOCK_TIMER_END_DATE', $tmp, true);

            $message .= $this->displayConfirmation($this->trans('Main Block is Updated.', [], 'Modules.Tvcmsadvanceblock.Admin'));
        }

        return $message;
    }

    protected function renderForm()
    {
        $helper = new HelperForm();

        $helper->show_toolbar = false;
        $helper->table = $this->table;
        $helper->module = $this;
        $helper->default_form_language = $this->context->language->id;
        $helper->allow_employee_form_lang = Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG', 0);

        $helper->identifier = $this->identifier;
        $helper->currentIndex = $this->context->link->getAdminLink('AdminModules', false)
            . '&configure=' . $this->name . '&tab_module=' . $this->tab . '&module_name=' . $this->name;
        $helper->token = Tools::getAdminTokenLite('AdminModules');
        $helper->show_cancel_button = true;
        $helper->tpl_vars = [
            'fields_value' => $this->getConfigFormValues(), // Add values for your inputs
            'languages' => $this->context->controller->getLanguages(),
            'id_language' => $this->context->language->id,
        ];

        $form = [];

        $tvcms_obj = new TvcmsAdvanceBlockStatus();
        $show_fields = $tvcms_obj->fieldStatusInformation();
        if ($show_fields['main_form']) {
            $form[] = $this->tvcmsAdvanceBlockMainTitleForm();
        }

        if ($show_fields['main_block_form']) {
            $form[] = $this->tvcmsAdvanceBlockMainBlockForm();
        }

        if ($show_fields['record_form']) {
            $form[] = $this->tvcmsAdvanceBlockForm();
        }

        return $helper->generateForm($form);
    }

    protected function tvcmsAdvanceBlockMainTitleForm()
    {
        $tvcms_obj = new TvcmsAdvanceBlockStatus();
        $show_fields = $tvcms_obj->fieldStatusInformation();
        $input = [];

        if ($show_fields['main_title']) {
            $input[] = [
                'col' => 7,
                'type' => 'text',
                'name' => 'TVCMSADVANCEBLOCK_TITLE',
                'label' => $this->trans('Main Title', [], 'Modules.Tvcmsadvanceblock.Admin'),
                'lang' => true,
            ];
        }

        if ($show_fields['main_short_description']) {
            $input[] = [
                'col' => 7,
                'type' => 'text',
                'name' => 'TVCMSADVANCEBLOCK_SUB_DESCRIPTION',
                'label' => $this->trans('Short Description', [], 'Modules.Tvcmsadvanceblock.Admin'),
                'lang' => true,
            ];
        }

        if ($show_fields['main_description']) {
            $input[] = [
                'col' => 7,
                'type' => 'text',
                'name' => 'TVCMSADVANCEBLOCK_DESCRIPTION',
                'label' => $this->trans('Description', [], 'Modules.Tvcmsadvanceblock.Admin'),
                'lang' => true,
            ];
        }

        if ($show_fields['main_image']) {
            $input[] = [
                'type' => 'image_file',
                'name' => 'TVCMSADVANCEBLOCK_IMG',
                'label' => $this->trans('Main Block Image', [], 'Modules.Tvcmsadvanceblock.Admin'),
            ];
        }

        return [
            'form' => [
                'legend' => [
                    'title' => $this->trans('Main Title', [], 'Modules.Tvcmsadvanceblock.Admin'),
                    'icon' => 'icon-support',
                ],
                'input' => $input,
                'submit' => [
                    'title' => $this->trans('Save', [], 'Modules.Tvcmsadvanceblock.Admin'),
                    'name' => 'submitvcmsAdvanceBlockMainTitleForm',
                ],
            ],
        ];
    }

    protected function tvcmsAdvanceBlockMainBlockForm()
    {
        $tvcms_obj = new TvcmsAdvanceBlockStatus();
        $show_fields = $tvcms_obj->fieldStatusInformation();
        $input = [];

        if ($show_fields['main_block_sub_title']) {
            $input[] = [
                'col' => 7,
                'type' => 'text',
                'name' => 'TVCMSADVANCEBLOCK_MAIN_BLOCK_SUB_TITLE',
                'label' => $this->trans('Main Sub Title', [], 'Modules.Tvcmsadvanceblock.Admin'),
                'lang' => true,
            ];
        }

        if ($show_fields['main_block_title']) {
            $input[] = [
                'col' => 7,
                'type' => 'text',
                'name' => 'TVCMSADVANCEBLOCK_MAIN_BLOCK_TITLE',
                'label' => $this->trans('Main Title', [], 'Modules.Tvcmsadvanceblock.Admin'),
                'lang' => true,
            ];
        }

        if ($show_fields['main_block_short_description']) {
            $input[] = [
                'col' => 7,
                'type' => 'text',
                'name' => 'TVCMSADVANCEBLOCK_MAIN_BLOCK_SUB_DESCRIPTION',
                'label' => $this->trans('Short Description', [], 'Modules.Tvcmsadvanceblock.Admin'),
                'lang' => true,
            ];
        }

        if ($show_fields['main_block_description']) {
            $input[] = [
                'col' => 7,
                'type' => 'text',
                'name' => 'TVCMSADVANCEBLOCK_MAIN_BLOCK_DESCRIPTION',
                'label' => $this->trans('Description', [], 'Modules.Tvcmsadvanceblock.Admin'),
                'lang' => true,
            ];
        }

        if ($show_fields['main_block_image']) {
            $input[] = [
                'type' => 'main_block_image_file',
                'name' => 'TVCMSADVANCEBLOCK_MAIN_BLOCK_IMG',
                'label' => $this->trans('Block Left Image', [], 'Modules.Tvcmsadvanceblock.Admin'),
            ];
        }

        if ($show_fields['main_block_back_image']) {
            $input[] = [
                'type' => 'main_block_back_image_file',
                'name' => 'TVCMSADVANCEBLOCK_MAIN_BLOCK_BACK_IMG',
                'label' => $this->trans('Background Image', [], 'Modules.Tvcmsadvanceblock.Admin'),
            ];
        }

        if ($show_fields['main_block_btn_caption']) {
            $input[] = [
                'col' => 4,
                'type' => 'text',
                'name' => 'TVCMSADVANCEBLOCK_MAIN_BLOCK_BTN_CAPTION',
                'label' => $this->trans('Button Caption', [], 'Modules.Tvcmsadvanceblock.Admin'),
                'lang' => true,
            ];
        }

        if ($show_fields['main_block_link']) {
            $input[] = [
                'col' => 7,
                'type' => 'text',
                'name' => 'TVCMSADVANCEBLOCK_MAIN_BLOCK_LINK',
                'label' => $this->trans('Link', [], 'Modules.Tvcmsadvanceblock.Admin'),
                'lang' => true,
            ];
        }

        if ($show_fields['main_block_timer_status']) {
            $input[] = [
                'col' => 7,
                'type' => 'text',
                'name' => 'TVCMSADVANCEBLOCK_MAIN_BLOCK_TIMER_TITLE',
                'label' => $this->trans('Main Block Timer Title', [], 'Modules.Tvcmsadvanceblock.Admin'),
                'lang' => true,
            ];
            $input[] = [
                'col' => 7,
                'type' => 'date',
                'name' => 'TVCMSADVANCEBLOCK_MAIN_BLOCK_TIMER_END_DATE',
                'label' => $this->trans('Main Block Timer End Date', [], 'Modules.Tvcmsadvanceblock.Admin'),
                // 'lang' => true,
            ];
        }

        return [
            'form' => [
                'legend' => [
                    'title' => $this->trans('Image & Caption Block', [], 'Modules.Tvcmsadvanceblock.Admin'),
                    'icon' => 'icon-support',
                ],
                'input' => $input,
                'submit' => [
                    'title' => $this->trans('Save', [], 'Modules.Tvcmsadvanceblock.Admin'),
                    'name' => 'submitvcmsAdvanceBlockMainBlockForm',
                ],
            ],
        ];
    }

    protected function tvcmsAdvanceBlockForm()
    {
        $tvcms_obj = new TvcmsAdvanceBlockStatus();
        $show_fields = $tvcms_obj->fieldStatusInformation();
        $input = [];

        if (Tools::getValue('action')) {
            if ('edit' == Tools::getValue('action')) {
                $input[] = [
                    'type' => 'hidden',
                    'name' => 'id',
                ];
            }
        }

        if ($show_fields['title']) {
            $input[] = [
                'col' => 7,
                'type' => 'text',
                'name' => 'title',
                'label' => $this->trans('Title', [], 'Modules.Tvcmsadvanceblock.Admin'),
                'lang' => true,
            ];
        }

        if ($show_fields['short_description']) {
            $input[] = [
                'col' => 7,
                'type' => 'text',
                'name' => 'short_description',
                'label' => $this->trans('Short Description', [], 'Modules.Tvcmsadvanceblock.Admin'),
                'lang' => true,
            ];
        }

        if ($show_fields['description']) {
            $input[] = [
                'col' => 7,
                'type' => 'textarea',
                'name' => 'description',
                'label' => $this->trans('Description', [], 'Modules.Tvcmsadvanceblock.Admin'),
                'lang' => true,
                'cols' => 40,
                'rows' => 10,
                'class' => 'rte',
                'autoload_rte' => true,
            ];
        }

        if ($show_fields['link']) {
            $input[] = [
                'col' => 7,
                'type' => 'text',
                'name' => 'link',
                'label' => $this->trans('Link', [], 'Modules.Tvcmsadvanceblock.Admin'),
                'desc' => $this->trans('You Must Write Full Link. Ex:- https://www.demo.com/', [], 'Modules.Tvcmsadvanceblock.Admin'),
            ];
        }

        if ($show_fields['image']) {
            $input[] = [
                'col' => 8,
                'type' => 'tvcmsadvanceblock_img',
                'name' => 'image',
                'label' => $this->trans('Image', [], 'Modules.Tvcmsadvanceblock.Admin'),
            ];
        }

        if ($show_fields['status']) {
            $input[] = [
                'type' => 'switch',
                'label' => $this->trans('Status', [], 'Modules.Tvcmsadvanceblock.Admin'),
                'name' => 'status',
                'desc' => $this->trans('Hide or Show Icons.', [], 'Modules.Tvcmsadvanceblock.Admin'),
                'is_bool' => true,
                'values' => [
                    [
                        'id' => 'active_on',
                        'value' => 1,
                        'label' => $this->trans('Show', [], 'Modules.Tvcmsadvanceblock.Admin'),
                    ],
                    [
                        'id' => 'active_off',
                        'value' => 0,
                        'label' => $this->trans('Hide', [], 'Modules.Tvcmsadvanceblock.Admin'),
                    ],
                ],
            ];
        }

        return [
            'form' => [
                'legend' => [
                    'title' => $this->trans('Advance Block', [], 'Modules.Tvcmsadvanceblock.Admin'),
                    'icon' => 'icon-support',
                ],
                'input' => $input,
                'submit' => [
                    'title' => $this->trans('Save', [], 'Modules.Tvcmsadvanceblock.Admin'),
                    'name' => 'submitvcmsAdvanceBlockForm',
                ],
            ],
        ];
    }

    public function hookDisplayBackOfficeHeader()
    {
        $this->context->controller->addJS($this->_path . 'views/js/back.js');
        $this->context->controller->addCSS($this->_path . 'views/css/back.css');
    }// hookDisplayBackOfficeHeader()

    protected function getConfigFormValues()
    {
        $fields = [];
        $languages = Language::getLanguages();
        $fields['id'] = '';
        foreach ($languages as $lang) {
            $fields['title'][$lang['id_lang']] = '';
            $fields['short_description'][$lang['id_lang']] = '';
            $fields['description'][$lang['id_lang']] = '';
        }

        $fields['image'] = '';
        $fields['link'] = '';
        $fields['status'] = '';

        if (Tools::getValue('action')) {
            if ('edit' == Tools::getValue('action')) {
                $id = Tools::getValue('id');
                $array_list = $this->showData($id);
                $array_list = $array_list[0];

                $fields['id'] = $id;
                foreach ($languages as $lang) {
                    if (!empty($array_list['lang_info'][$lang['id_lang']])) {
                        $fields['title'][$lang['id_lang']] = $array_list['lang_info'][$lang['id_lang']]['title'];
                        $tmp = $array_list['lang_info'][$lang['id_lang']]['short_description'];
                        $fields['short_description'][$lang['id_lang']] = $tmp;
                        $tmp = $array_list['lang_info'][$lang['id_lang']]['description'];
                        $fields['description'][$lang['id_lang']] = $tmp;
                    }
                }

                $fields['image'] = $array_list['image'];
                $fields['link'] = $array_list['link'];
                $fields['status'] = $array_list['status'];
            }
        }

        foreach ($languages as $lang) {
            // Main Title Information
            $tmp = Configuration::get('TVCMSADVANCEBLOCK_TITLE', $lang['id_lang']);
            $fields['TVCMSADVANCEBLOCK_TITLE'][$lang['id_lang']] = $tmp;

            $tmp = Configuration::get('TVCMSADVANCEBLOCK_SUB_DESCRIPTION', $lang['id_lang']);
            $fields['TVCMSADVANCEBLOCK_SUB_DESCRIPTION'][$lang['id_lang']] = $tmp;

            $tmp = Configuration::get('TVCMSADVANCEBLOCK_DESCRIPTION', $lang['id_lang']);
            $fields['TVCMSADVANCEBLOCK_DESCRIPTION'][$lang['id_lang']] = $tmp;

            $tmp = Configuration::get('TVCMSADVANCEBLOCK_IMG', $lang['id_lang']);
            $fields['TVCMSADVANCEBLOCK_IMG'][$lang['id_lang']] = $tmp;

            //  Main Block Information
            $tmp = Configuration::get('TVCMSADVANCEBLOCK_MAIN_BLOCK_SUB_TITLE', $lang['id_lang']);
            $fields['TVCMSADVANCEBLOCK_MAIN_BLOCK_SUB_TITLE'][$lang['id_lang']] = $tmp;

            $tmp = Configuration::get('TVCMSADVANCEBLOCK_MAIN_BLOCK_TITLE', $lang['id_lang']);
            $fields['TVCMSADVANCEBLOCK_MAIN_BLOCK_TITLE'][$lang['id_lang']] = $tmp;

            $tmp = Configuration::get('TVCMSADVANCEBLOCK_MAIN_BLOCK_SUB_DESCRIPTION', $lang['id_lang']);
            $fields['TVCMSADVANCEBLOCK_MAIN_BLOCK_SUB_DESCRIPTION'][$lang['id_lang']] = $tmp;

            $tmp = Configuration::get('TVCMSADVANCEBLOCK_MAIN_BLOCK_DESCRIPTION', $lang['id_lang']);
            $fields['TVCMSADVANCEBLOCK_MAIN_BLOCK_DESCRIPTION'][$lang['id_lang']] = $tmp;

            $tmp = Configuration::get('TVCMSADVANCEBLOCK_MAIN_BLOCK_LINK', $lang['id_lang']);
            $fields['TVCMSADVANCEBLOCK_MAIN_BLOCK_LINK'][$lang['id_lang']] = $tmp;

            $tmp = Configuration::get('TVCMSADVANCEBLOCK_MAIN_BLOCK_BTN_CAPTION', $lang['id_lang']);
            $fields['TVCMSADVANCEBLOCK_MAIN_BLOCK_BTN_CAPTION'][$lang['id_lang']] = $tmp;

            $tmp = Configuration::get('TVCMSADVANCEBLOCK_MAIN_BLOCK_IMG', $lang['id_lang']);
            $fields['TVCMSADVANCEBLOCK_MAIN_BLOCK_IMG'][$lang['id_lang']] = $tmp;

            $tmp = Configuration::get('TVCMSADVANCEBLOCK_MAIN_BLOCK_BACK_IMG', $lang['id_lang']);
            $fields['TVCMSADVANCEBLOCK_MAIN_BLOCK_BACK_IMG'][$lang['id_lang']] = $tmp;

            $tmp = Configuration::get('TVCMSADVANCEBLOCK_MAIN_BLOCK_TIMER_TITLE', $lang['id_lang']);
            $fields['TVCMSADVANCEBLOCK_MAIN_BLOCK_TIMER_TITLE'][$lang['id_lang']] = $tmp;

            // $tmp = Configuration::get('TVCMSADVANCEBLOCK_MAIN_BLOCK_TIMER_END_DATE', $lang['id_lang']);
            // $fields['TVCMSADVANCEBLOCK_MAIN_BLOCK_TIMER_END_DATE'][$lang['id_lang']] = $tmp;
        }
        $tmp = Configuration::get('TVCMSADVANCEBLOCK_MAIN_BLOCK_TIMER_END_DATE');
        $fields['TVCMSADVANCEBLOCK_MAIN_BLOCK_TIMER_END_DATE'] = $tmp;

        $path = _MODULE_DIR_ . $this->name . '/views/img/';
        $this->context->smarty->assign('path', $path);

        return $fields;
    }

    public function showAdminResult()
    {
        $tvcms_obj = new TvcmsAdvanceBlockStatus();
        $show_fields = $tvcms_obj->fieldStatusInformation();
        $default_lang_id = $this->context->language->id;

        $array_list = $this->showAdminData();

        if (empty($array_list)) {
            return '';
        }
        $this->context->smarty->assign('array_list', $array_list);
        $this->context->smarty->assign('show_fields', $show_fields);
        $this->context->smarty->assign('default_lang_id', $default_lang_id);

        return $this->display(__FILE__, 'views/templates/admin/tvcmsadvanceblock_manage.tpl');
    }

    public function hookdisplayHeader()
    {
        // start countdown timer
        // $timerEndDate = Configuration::get('TVCMSADVANCEBLOCK_MAIN_BLOCK_TIMER_END_DATE');
        // $timerEndDate = date("m/d/Y", strtotime($timerEndDate));
        // Media::addJsDef(array(
        //     'timerEndDate' => $timerEndDate
        // ));
        // $this->context->controller->addJS($this->_path.'views/js/kinetic.js');
        // $this->context->controller->addJS($this->_path.'views/js/jquery.final-countdown.js');
        // end

        $this->context->controller->addJS($this->_path . 'views/js/front.js');
        $this->context->controller->addCSS($this->_path . 'views/css/front.css');
    }

    public function hookDisplayTopColumn()
    {
        return $this->hookDisplayHome();
    }

    public function hookDisplayFooterBefore()
    {
        return $this->hookDisplayHome();
    }

    public function getArrMainTitle($main_heading, $main_heading_data)
    {
        if (!$main_heading['main_title'] || empty($main_heading_data['title'])) {
            $main_heading['main_title'] = false;
        }
        if (!$main_heading['main_sub_title'] || empty($main_heading_data['short_desc'])) {
            $main_heading['main_sub_title'] = false;
        }
        if (!$main_heading['main_description'] || empty($main_heading_data['desc'])) {
            $main_heading['main_description'] = false;
        }
        if (!$main_heading['main_image'] || empty($main_heading_data['image'])) {
            $main_heading['main_image'] = false;
        }
        if (!$main_heading['main_title']
            && !$main_heading['main_sub_title']
            && !$main_heading['main_description']
            && !$main_heading['main_image']) {
            $main_heading['main_status'] = false;
        }

        return $main_heading;
    }

    public function hookDisplayHome()
    {
        $cookie = Context::getContext()->cookie;
        $id_lang = $cookie->id_lang;
        $result = [];
        $result = $this->showData();

        $tvcms_obj = new TvcmsAdvanceBlockStatus();
        $show_fields = $tvcms_obj->fieldStatusInformation();
        $main_heading = $tvcms_obj->fieldStatusInformation();
        if ($main_heading['main_status']) {
            $main_heading_data = [];
            $main_heading_data['title'] = Configuration::get('TVCMSADVANCEBLOCK_TITLE', $id_lang);
            $main_heading_data['short_desc'] = Configuration::get('TVCMSADVANCEBLOCK_SUB_DESCRIPTION', $id_lang);
            $main_heading_data['desc'] = Configuration::get('TVCMSADVANCEBLOCK_DESCRIPTION', $id_lang);
            $main_heading_data['image'] = Configuration::get('TVCMSADVANCEBLOCK_IMG', $id_lang);
            $main_heading = $this->getArrMainTitle($main_heading, $main_heading_data);
            $main_heading['data'] = $main_heading_data;
        }
        $this->context->smarty->assign('main_heading', $main_heading);
        $AdvanceBlockImgpath = _MODULE_DIR_ . $this->name . '/views/img/';
        $this->context->smarty->assign('AdvanceBlockImgpath', $AdvanceBlockImgpath);

        // if (Context::getContext()->getDevice() == 1) {
        //     $AdvanceBlockImgpath_bk = _MODULE_DIR_ . $this->name . "/views/img/";
        //     $this->context->smarty->assign("AdvanceBlockImgpath_bk", $AdvanceBlockImgpath_bk);
        // } else if (Context::getContext()->getDevice() == 2) {
        //     $AdvanceBlockImgpath_bk = _MODULE_DIR_ . $this->name . "/views/img/medium/";
        //     $this->context->smarty->assign("AdvanceBlockImgpath_bk", $AdvanceBlockImgpath_bk);
        // } else {
        //     $AdvanceBlockImgpath_bk = _MODULE_DIR_ . $this->name . "/views/img/small/";
        //     $this->context->smarty->assign("AdvanceBlockImgpath_bk", $AdvanceBlockImgpath_bk);
        // }
        $disArrResult = [];
        $disArrResult['path'] = _MODULE_DIR_ . $this->name . '/views/img/';

        $this->context->smarty->assign('show_fields', $show_fields);
        $this->context->smarty->assign('arr_result', $result);
        $this->context->smarty->assign('id_lang', $id_lang);
        $this->context->smarty->assign('dis_arr_result', $disArrResult);

        return $this->display(__FILE__, 'views/templates/front/display_home.tpl');
    }
}
